package u1.examen03032021.fuentes;

public class Habitacion
{
	private int numero;

	public Habitacion(int numero)
	{
		this.numero = numero;
	}

	public int getNumero()
	{
		return numero;
	}

	public void setNumero(int numero)
	{
		this.numero = numero;
	}

	@Override
	public String toString()
	{
		return "habitaci�n n�mero "+this.numero;
	}
	
	

}
