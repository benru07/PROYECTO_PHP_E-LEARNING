package u1.examen03032021.fuentes;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Hotel {

	private List<Reserva> tReservas;

	public Hotel() {
		this.tReservas = new ArrayList<Reserva>();
	}

	public List<Reserva> gettReservas() {
		return tReservas;
	}

	public void guardaClientesEnTXT(File ficheroClientes) {}
	
	public boolean cargarReservasDeFicheroBinario(File ficheroReservas) {
		
		return false;
	}
	
	public void guardarReservasEnFicheroBinario(File ficheroReservas) {
	
	}
	
	public void guardarReservasEnFicheroXML(File ficheroXML) {

	}
	
	public static void mostrarReservasDeXML(File ficheroXML) {
		
	}
	

}
