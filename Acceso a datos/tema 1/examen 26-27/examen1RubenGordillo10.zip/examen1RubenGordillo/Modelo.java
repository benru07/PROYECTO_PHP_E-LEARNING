package examen1RubenGordillo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Modelo {
	private Map<String, ModeloIA> catalogoModelos = new HashMap<>();
	private List<Evaluacion> evaluaciones = new ArrayList<>();

	public Modelo() {
		super();
	}

	public Map<String, ModeloIA> getCatalogoModelos() {
		return catalogoModelos;
	}

	public List<Evaluacion> getEvaluaciones() {
		return evaluaciones;
	}

	public boolean addModeloIA(ModeloIA modelo) {
		if (!catalogoModelos.containsKey(modelo.getCodigo())) {
			catalogoModelos.put(modelo.getCodigo(), modelo);
			return true;
		}
		return false;
	}

	public boolean removeModeloIAByCodigo(String codigo) {
		return catalogoModelos.remove(codigo) != null;
	}

	public void addEvaluacion(Evaluacion evaluacion) {
		evaluaciones.add(evaluacion);
	}

	public int obtenerNumErrores() {
		int numErrores = 0;
		for (Evaluacion ev : evaluaciones) {
			if (!catalogoModelos.containsKey(ev.getCodigoModelo())) {
				numErrores++;
			}
		}
		return numErrores;
	}

	// a) Gestion del log de errores
	public boolean creaArchivoErrores() {
		boolean hayErrores = false;
		File errores = new File("errores.log");
		if (obtenerNumErrores() > 0) {
			hayErrores = true;
			try (BufferedWriter bw = new BufferedWriter(new FileWriter(errores))) {

				bw.write("Hay " + obtenerNumErrores()
						+ " evaluaciones aociadas a modelos no registrados en el catalogo");

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}else {
			errores.delete();	
		}
		
		return hayErrores; // Implementacion pendiente
	}

	// b) Carga de modelos desde XML (DOM)
	public int addModelosDeXML(String nombreFichero) {
		int modelos = 0;

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(nombreFichero);
			document.getDocumentElement().normalize();

			NodeList modelosXML = document.getElementsByTagName("modelo");

			for (int i = 0; i < modelosXML.getLength(); i++) {

				Element elementoModelo = (Element) modelosXML.item(i);

				String codigo = elementoModelo.getElementsByTagName("codigo").item(0).getTextContent();
				String nombre = elementoModelo.getElementsByTagName("nombre").item(0).getTextContent();
				String proveedor = elementoModelo.getElementsByTagName("proveedor").item(0).getTextContent();

				ModeloIA anyadir = new ModeloIA(codigo, nombre, proveedor);

				catalogoModelos.put(codigo, anyadir);
				modelos++;

			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException e) {
			
		}
		
		return modelos; // Implementaci�n pendiente

	}

	// por si me da por hacerlo: tengo que leerlo y cada linea pasrsear por " " con
	// el parse se hacía un array con el parse u añadias cada 1 huevo del array a su
	// posición correspondiente usar el split(";")
	// c) // 3. Lectura de archivo de texto plano
	public int addEvaluacionesDeTexto(String nombreFichero) {

		int totalEvaluacionesTXT = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(nombreFichero))) {

			String linea = "";

			while ((linea = br.readLine()) != null) {
				
				String[] evluacionesTXT = linea.split(";");

				String codigoModelo = evluacionesTXT[0];
				String nombreBechMarck = evluacionesTXT[1];
				Double puntuacion = Double.valueOf(evluacionesTXT[2]);

				Evaluacion ev = new Evaluacion(codigoModelo, nombreBechMarck, puntuacion);

				evaluaciones.add(ev);

				totalEvaluacionesTXT++;

			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 


		return totalEvaluacionesTXT; // Implementaci�n pendiente
	}

	// d) Guardar evaluaciones en binario
	public void escribirEvaluacionesEnBinario(String nombreFichero) {
		// Implementaci�n pendiente

		try (ObjectOutputStream oss = new ObjectOutputStream(new FileOutputStream(nombreFichero))) {
			for (Evaluacion e : evaluaciones) {
				oss.writeObject(e);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	// e) Leer evaluaciones desde binario
	public ArrayList<Evaluacion> leerEvaluacionesDeBinario(String nombreFichero) {

		ArrayList<Evaluacion> devolver = new ArrayList<Evaluacion>();

		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreFichero))) {
			while (true) {
				Evaluacion v = (Evaluacion) ois.readObject();
				devolver.add(v);
			}

		} catch (EOFException e) {
			System.out.println("carga completada");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return devolver; // Implementacion pendiente
	}

	// f) Exportar evaluaciones a XML
	public void generaXMLEvaluaciones(String nombreFichero) {
		// Implementacion pendiente

		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			DOMImplementation implementation = builder.getDOMImplementation();
			Document document = implementation.createDocument(null, "evlacuaciones", null);

			document.setXmlVersion("1.0");
			document.setXmlStandalone(true);

			for (Evaluacion evaluacion : evaluaciones) {

				Element elemEvalucacion = document.createElement("evaluacion");
				document.getDocumentElement().appendChild(elemEvalucacion);

				Element elemCodigoModelo = document.createElement("codigoModelo");
				elemCodigoModelo.setTextContent(evaluacion.getCodigoModelo());
				elemEvalucacion.appendChild(elemCodigoModelo);

				Element elemNombreBenchmark = document.createElement("nombreBenchmark");
				elemNombreBenchmark.setTextContent(evaluacion.getNombreBenchmark());
				elemEvalucacion.appendChild(elemNombreBenchmark);

				Element elemPuntuacion = document.createElement("Puntuacion");
				elemPuntuacion.setTextContent(String.valueOf(evaluacion.getPuntuacion()));
				elemEvalucacion.appendChild(elemPuntuacion);
			}

			Source source = new DOMSource(document);
			Result result = new StreamResult(nombreFichero);
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(source, result);

		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerFactoryConfigurationError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
