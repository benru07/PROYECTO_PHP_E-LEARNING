package u1.examen25102026.fuentes;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Modelo {
	private Map<String, ModeloIA> catalogoModelos = new HashMap<>();
	private List<Evaluacion> evaluaciones = new ArrayList<>();

	public Modelo() {
		super();
	}

	public Map<String, ModeloIA> getCatalogoModelos() {
		return catalogoModelos;
	}

	public List<Evaluacion> getEvaluaciones() {
		return evaluaciones;
	}

	public boolean addModeloIA(ModeloIA modelo) {
		if (!catalogoModelos.containsKey(modelo.getCodigo())) {
			catalogoModelos.put(modelo.getCodigo(), modelo);
			return true;
		}
		return false;
	}

	public boolean removeModeloIAByCodigo(String codigo) {
		return catalogoModelos.remove(codigo) != null;
	}

	public void addEvaluacion(Evaluacion evaluacion) {
		evaluaciones.add(evaluacion);
	}

	public int obtenerNumErrores() {
		int numErrores = 0;
		for (Evaluacion ev : evaluaciones) {
			if (!catalogoModelos.containsKey(ev.getCodigoModelo())) {
				numErrores++;
			}
		}
		return numErrores;
	}

	// a) Gesti�n del log de errores
	public boolean creaArchivoErrores() {
		return false; // Implementaci�n pendiente
	}

	// b) Carga de modelos desde XML (DOM)
	public int addModelosDeXML(String nombreFichero) {
		
		return 0; // Implementaci�n pendiente
	}

	// c) // 3. Lectura de archivo de texto plano
	public int addEvaluacionesDeTexto(String nombreFichero) {
		return 0; // Implementaci�n pendiente
	}

	// d) Guardar evaluaciones en binario
	public void escribirEvaluacionesEnBinario(String nombreFichero) {
		// Implementaci�n pendiente
	}

	// e) Leer evaluaciones desde binario
	public ArrayList<Evaluacion> leerEvaluacionesDeBinario(String nombreFichero) {
		
		return null; // Implementaci�n pendiente
	}

	// f) Exportar evaluaciones a XML
	public void generaXMLEvaluaciones(String nombreFichero) {
		// Implementaci�n pendiente
	}
		
}
