package u1.examen03032021.fuentes;

public class Reserva
{
	private Cliente cliente;
	private Habitacion habitaci�n;
	private Fecha fechaInicio;
	private Fecha fechaFin;
	
	public Reserva(Cliente cliente, Habitacion habitaci�n, Fecha fechaInicio, Fecha fechaFin)
	{
		this.cliente = cliente;
		this.habitaci�n = habitaci�n;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
	}

	public Cliente getCliente()
	{
		return cliente;
	}

	public void setCliente(Cliente cliente)
	{
		this.cliente = cliente;
	}

	public Habitacion getHabitaci�n()
	{
		return habitaci�n;
	}

	public void setHabitaci�n(Habitacion habitaci�n)
	{
		this.habitaci�n = habitaci�n;
	}

	public Fecha getFechaInicio()
	{
		return fechaInicio;
	}

	public void setFechaInicio(Fecha fechaInicio)
	{
		this.fechaInicio = fechaInicio;
		
	}

	public Fecha getFechaFin()
	{
		return fechaFin;
	}

	public void setFechaFin(Fecha fechaFin)
	{
		this.fechaFin = fechaFin;
	}

	@Override
	public String toString()
	{
		return this.cliente+": "+this.habitaci�n+":[" + this.fechaInicio + "-"+this.fechaFin+"]";
	}
	
	

}
